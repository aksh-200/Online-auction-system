export default function FeedbackSeller() {
  return (
    <div>
      <h2>Feedback for Seller</h2>
    </div>
  );
}
