export default function FeedbackBidder() {
  return (
    <div>
      <h2>Feedback for bidder</h2>
    </div>
  );
}
